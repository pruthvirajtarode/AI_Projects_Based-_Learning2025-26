Mario-Shooter-Web-FULLSCREEN-FINAL
=================================
Final verified package: auto-fullscreen on mobile, toast message (green glow), score centered and visible, mobile controls, pause, restart, instant audio start.

Local test:
python -m http.server 8000
open http://localhost:8000

Deploy to Netlify:
1. Go to https://app.netlify.com/drop
2. Drag & drop the contents of this folder (ensure index.html at root)
3. Wait for the deploy to finish and open the site
